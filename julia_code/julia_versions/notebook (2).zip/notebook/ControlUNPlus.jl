using ControlSystems
using LinearAlgebra
using Alert
using Plots; gr(linewidth = 2, grid=:true)
using Printf
Base.show(io::IO, f::Float64) = @printf(io, "%.4f", f)
using LaTeXStrings
using Latexify
using PolynomialRoots
using Polynomials
function dise_2p(P,T,polos_obs)
   m = length(polos_obs)
   P = tf(P);
   N, D = tfdata(P);
   n = length(D) - 1
   if m < n-1
      throw("dise_2p: número de polos del observador, insuficientes")
      return
   end

     # CALCULA UN CONTROLADOR DE DOS PARÁMETROS
     # Para la planta dada por una función de transferencia P
     # La función de transferencia de lazo cerrado deseada es T
     # m: orden del controlador
     # PolosObs: Polos del observador
    
     # Forma polinomio del observador
   pol = polos_obs;
   Dhb = poly(pol);
   div = tf(1,N);
   H = minreal(T * div); 
   Nh, Dh = tfdata(H);
   L = convol(Nh, Dhb);
   F = convol(Dh, Dhb);
   n = length(D)-1;
   m = length(pol); # El número de polos del observador
   # Forma polinomio con los polos
   l = n - length(N) + 1;
   Na = zeros(length(D));
   Na[l+1:end] = N;
   Sm = zeros(Float64,n+m+1,2*(m+1));
   Smj = zeros(Float64,n+m+1,2*m+1);
   
   for k=1:m+1
      Sm[k:k+n,k]=D;
      Sm[k:k+n,k+m+1]=Na;
   end
   #
   if m > n - 1
      # Si es posible, disena un controlador que rechaza perturbaciones 
      #Smj=Sm[:,1:end .!= m+1]
      jj = 0
      for j in 1:n+m+1
         if j == m+1
            continue
         else
            jj += 1
            Smj[:,jj] = Sm[:,j]
         end
      end
      if rank(Smj)>=n+m+1
         XY=Smj\F;
         A_c=[XY[1:m];0];
         M_c=XY[m+1:end];
      else
         XY=Sm\F;
         A_c=XY[1:m+1];
         M_c=XY[m+2:end];  
      end
   elseif m==n-1
      XY=Sm\F;
      A_c=XY[1:m+1];
      M_c=XY[m+2:2*m+2]; 
   end
   Kr = tf(real.(L)[:,1],real.(A_c[:,1]))
   Ky = tf(real.(M_c),real.(A_c[:,1]));
   T = minreal(Kr * feedback(P, Ky));
   Gur=minreal(T/P);
   Kr, Ky, T, Gur
end

function asigne_polos(P,pol)
    # CALCULA UN CONTROLADOR CON REALIMENTACIÓN UNITARIA
    # Para la planta dada por una funcion de transferencia P
    # Los polos se asignan en el vector pol
    # m: orden del controlador
    P1 = tf(P);
    # Obtiene los datos de la planta
    P1 = tf(P);
    # Obtiene los datos de la planta
    N,D = tfdata(P1);
    # n =  orden de la planta
    n = length(D)-1;
    l = length(D)-length(N);
    # Calcula orden del sistema de lazo cerrado
    nMm = length(pol);
    m = nMm-n;
    # Forma polinomio con los polos
    DT = fromroots(pol);
    Na = zeros(length(D));
    Na[l+1:end]  =  N;
    DT = reverse(DT.coeffs);
    # Forma la Matriz de Sylvester
    Sm = zeros(n+m+1,2*(m+1));
    for k = 1:m+1
      Sm[k:k+n,k] = D;
      Sm[k:k+n,k+m+1] = Na;
   end
   ind_error = 0;
   if m > n - 1;
      # Si es posible, disena un controlador que rechaza perturbaciones 
      Smj = Sm[:, 1:end .!= (m+1) ]
      #Smj = Sm[:,Not(m+1)];
      if rank(Smj)>=n+m+1;
         XY = Smj\DT;
         Y = [XY[1:m];0];
         X = XY[m+1:end] ;
      else
         XY = Sm\DT;
         Y = XY[1:m+1];
         X = XY[m+2:end] ; 
      end
   elseif m==n-1
      XY = Sm\DT;
      Y = XY[1:m+1];
      X = XY[m+2:2*m+2] ;
   else
      ind_error = 1;
      alert("asigne_polos: Número de polos insuficiente")
   end
   K = tf(X,Y);
   T = feedback(K * P);
   Gur = minreal(T/P);
   S = minreal(1 - T);
   K, T, Gur, S, ind_error
end

function convol(h,u)
    n = length(h);
    m = length(u);
    l = n + m-1;
    w = zeros(Complex,l,1);
    for i in 1:l
        for j in max(1,i+1-m):min(i,n)
            w[i] = w[i] + h[j]*u[i-j+1];
        end
    end
    w;
end

function poly(raices)
   n = length(raices)
   pol = [1.0+0.0im, -raices[1]]
   for i in 2:n
       pol = convol(pol, [1.0+0.0im, -raices[i]])
   end
   return real.(pol)
end

function reverse_poly(polyn)
    n = length(polyn)
    poly_r = zeros(Complex,n)
    for i in 1:n
        poly_r[i]  = polyn[n + 1 - i]
    end
    return poly_r
end


function polroots(polin)
   raices_p = PolynomialRoots.roots(reverse_poly(polin))
end

function lq_1(P,q)
   n, d = tfdata(P);
   Qd = convol(d, cambia_signo(d));
   Qn = q * convol(n, cambia_signo(n));
   Qa = zeros(Complex,length(Qd));
   l = length(Qd) - length(Qn);
   Qa[l+1:end] = Qn;
   Q = Qd .+ Qa;
   r = polroots(Q[:,1]);
   inestables = real.(r).> 0;
   indices = findall(iszero,inestables);
   dT = poly(r[indices,1])[:,1];
   T = tf(n,dT); 
   T = T / dcgain(T)[1];
   Gur = minreal(T / P) ;
   T, Gur
end
    

function tfdata(G)
   # Obtiene numerador y denominador de fcn de transferencia
   # para sistema SISO
    G = tf(G)
    n = num(G)[1,1]
    d = den(G)[1,1]
    n, d
end

function cambia_signo(n)
    n1 = n
    long = length(n1) - 1
    n2 = ones(long+1)
     for j in long:-2:1
       n2[j] = -1
    end
    return n2 .*n
end
   



function step_plt(sys, t_max)
   #=
   Grafica la respuesta al escalón del sistema sys
   =#
   rey = step(sys,t_max)
   si = stepinfo(rey)
   plot(si,legend=:bottomright)
end 

#=
Evalúa el máximo de la respuesta al escalón de sys
=#
function max_resp_step(sys)
   reu = step(sys)
   v_max = maximum(abs.(reu.y))
   v_max
end   

#=
Grafica respuesta al escalón de salida y de control
=#
function yu_stp_plt(T, Gur, tmax)
   re_y = step(T, tmax)
   sy = stepinfo(re_y)
   re_u = step(Gur, tmax)
   su = stepinfo(re_u)
   plot(plot(sy,legend=:bottomright), plot(su))
end











using RobustAndOptimalControl
using Printf



function generateCode(Ab, Bb, C, D, L) 

   code = ""
   code = "float computeController(float e, float umin, float umax){\n";
   code = code * "    // This function computes the control law for a discretized controller Cd(z)\n";
   code = code * "    // e = ref - y is the current error in the controlled system\n";
   code = code * "    // and umin and umax are the limits of the control signal\n\n"; 
   code = code * "    // using the following state space representation\n";
   code = code * "    //       x[n+1]= Ab*x[n] + Bb*e[n]\n";
   code = code * "    //       u[n]= sat(C*x[n] + D*e[n])\n";
   code = code * "    // where  Ab = A - L*C and Bb = B - L*D\n";
   code = code * "    // with  L the gain of a Kalman Filter";
   code = code * "\n\n";

   code = code * "    // The following constants define the Ab matrix\n";
   for i = 1:size(Ab,1)  # Filas
       for j = 1:size(Ab,2)  # Columnas
           code = code * "    const float aw$i$j = " * @sprintf("%0.20f" , Ab[i,j]) * ";\n"
       end

   end
   code = code * "\n";
   code = code * "    // The following constants define the Bb matrix\n";
   for i = 1:size(Bb,1)  #Filas
           code = code *"    const float bw$i = " * @sprintf("%0.20f" , Bb[i]) * ";\n"  
   end
   code = code * "\n";
   code = code * "    // The following constants define the C matrix\n";
   for i = 1:size(C,2)  #Filas
           code = code * "    const float c$i = " * @sprintf("%0.20f",C[i])  * ";\n"  
   end
   code = code * "\n";
   code = code * "    // The following constant define the D scalar\n";
   for i = 1:size(D,2)  #Filas
           code = code * "    const float d$i = " * @sprintf("%0.20f", D[i]) * ";\n"  
   end
   code = code * "\n";
   code = code * "    // The following constants define the antwindup vector L\n";
   for i = 1:size(L,1)  #Filas
           code = code * "    const float l$i = " * @sprintf("%0.20f", L[i]) * ";\n"  
   end

   code = code * "\n";
   code = code * "    // The following variables represent the states x[n]\n";
   code = code * "    // in the state-space representation. They must be declared\n";
   code = code * "    // as static to retain their values between function calls.\n";
   for i = 1:size(Bb,1)  #Filas
       code = code * "    static float x$i = 0;\n"  
   end
   code = code * "\n";
   code = code * "    // The following variables are the new computed states x[n+1]\n";
   code = code * "    // of the state space representation\n";
   for i = 1:size(Bb,1)  #Filas
       code = code * "    float x$(i)_new = 0;\n"  
   end
   code = code * "\n";
   code = code * "    // The following variable is the control signal. \n";
   code = code * "    // it also must be declared as static to retain its value between function calls. \n";
   code = code * "    static float u = 0;\n"
   code = code * "\n";

   code = code * "    /*************************************************\n";
   code = code * "                THIS IS THE CONTROLLER'S CODE\n";
   code = code * "    **************************************************/\n\n";
   code = code * "    // Compute the new predicted state x[n+1] = Ab*x[n] + Bb*e[n] + L*u[n]\n"

   for i = 1:size(Ab,1)  #Filas
       code = code * "    x$(i)_new = "
       for j = 1:size(Ab,2)  #Columnas
           code = code * "aw$(i)$(j)*x$(j) + "    
       end
       code = code * "bw$(i)*e + l$(i)*u;"
       code = code * "\n";    
   end
   code = code * "\n";
   code = code * "    // Compute the control output u[n] = C*x[n] + D*e[n]\n"
   code = code * "    u = "
   for i = 1:size(C,2)  #Filas
       code = code * "c$(i)*x$(i) + "   
   end
   for i = 1:size(D,2)  #Filas
           code = code * "d$(i)*e;" 
   end
   code = code * "\n\n"; 
   code = code * "    // Saturate control signal\n";
   code = code * "    u = constrain(u, umin, umax);\n";
   code = code * "\n"; 

   code = code * "    // Make the predicted state the current state: x[n] <- x[n+1]\n";
   for i = 1:size(Ab,1)
       code = code * "    x$(i) = x$(i)_new;\n"
   end
   code = code * "\n";
   code = code * "    // now, the control signal is available to the main control routine\n";
   code = code * "    return u;\n";
   code = code * "}\n";

   write("controller.h", code);
   println("The controller code has been generated")
   return true

end

using Roots
function bandwidth(sys)
   # calculate the 3db bandwidth of a feedback system
   gain_3db = 20*log10(dcgain(sys)[1]) - 3
   function res(w)
       mag = bode(sys, [w])[1][1]
       magdb = 20*log10(mag)         
       magdb - gain_3db
   end
   res = find_zero(res, (exp10(-3), exp10(3)))
   return res
end

function bodemag(sys; ω=nothing)
   # Plot the frecuency response in magnitude (dB) of a feedback system
   if ω === nothing
       ω = exp10.(LinRange(-2, 2, 500))  # Rango de frecuencias por defecto (10⁻² a 10² rad/s)
   end
   mag, _, ω = bode(sys, ω)  # Obtenemos la magnitud
   mag_db = 20 * log10.(vec(mag))  # Convertimos a dB
   plot(ω, mag_db, xscale=:log10, xlabel="Frecuency (rad/s)", ylabel="Magnitude (dB)", title="Closed Loop Magnitude", lw=2)
end
